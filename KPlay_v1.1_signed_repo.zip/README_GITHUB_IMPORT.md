# KPlay — Ready-to-Import GitHub Repo (Auto Keystore)

**No installs needed.** Build a signed Release APK entirely on GitHub.

## Steps
1. Go to https://github.com/new/import → **Upload from your computer** → choose this ZIP.
2. After import, open **Actions** → run **Release APK (Auto Keystore)**.
3. Download artifact **kplay-release-apk** → inside is `app-release.apk`.
